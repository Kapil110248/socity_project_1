-- AlterTable
ALTER TABLE `complaint` ADD COLUMN `escalatedToSuperAdmin` BOOLEAN NOT NULL DEFAULT false;
